import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
let checked=0;
for(const file of await fs.readdir(root+'/dist')){
 if(!/\.(html|css|js)$/.test(file))continue;
 const text=await fs.readFile(root+'/dist/'+file,'utf8');
 if(/(?:src|href)\s*=\s*["']\//.test(text))throw new Error('Root-relative asset in '+file);
 for(const m of text.matchAll(/(?:\.\/assets\/[\w.-]+|\.\/(?:styles|chat|brand)\.css|\.\/(?:data|app|chat-engine|chat)\.js)/g)){
  await fs.access(path.join(root,'dist',m[0]));checked++;
 }
 if(/https?:\/\/[^\s"'<>]*(?:chatgpt\.site|fonts\.googleapis\.com|fonts\.gstatic\.com)/.test(text))throw new Error('Runtime hosting dependency in '+file);
}
for(const forbidden of ['.git','.openai','.env']){try{await fs.access(root+'/'+forbidden);if(forbidden!=='.git')throw new Error('Unexpected private packaging file: '+forbidden);}catch(e){if(e.code!=='ENOENT')throw e;}}
console.log('Verified '+checked+' local asset references and independent static hosting');
